# Sentiment-Analysis-UI
UI to test sentiment analysis on hotel reviews

All the images and svm model pickle file are present in this folder
Just download the folder and run python flask-api.py from terminal

Launch the web page http://0.0.0.0:5000/ and test the reviews by adding text in textarea.
